import LoginandRegister from "./component/lrc/LoginandRegister";
import Forgetpassword from './component/forgottenpassword/Forgetpassword';
import './App.css'

function App() {
  return (
    <>
      {/* // <Login/> */}
      <LoginandRegister/>
      {/* <Forgetpassword/> */}
    </>
  );
}

export default App;
