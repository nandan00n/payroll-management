import React from 'react';
import './topbar.css'
// import {NotificationsIcon,SettingsIcon, LanguageIcon} from '@mui/icons-material';

export default function Topbar() {
  return
  (<div className='topbar'>
    <div className='topbarWrapper'>
      <div className='topbarleft'>
        <span className="logo">PayRoll Management</span>
      </div>
      <div className='topbarright'>
        <div className="topbarIconContainer">
          {/* <NotificationsIcon/> */}
          <span className='topbarIconBadge'>2</span>
        </div>
        <div className="topbarIconContainer">
          {/* <LanguageIcon/> */}
          <span className='topbarIconBadge'>2</span>
        </div>

        <div className="topbarIconContainer">
          {/* <SettingsIcon/> */}
          <span className='topbarIconBadge'>2</span>
        </div>
        <img src='' className='topAvatar' />
      </div>
    </div>
  </div>
  )
}
